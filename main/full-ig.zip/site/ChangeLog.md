# Change Log - v0.0.1

* [**Table of Contents**](toc.md)
* **Change Log**

## Change Log

### Änderungen seit der letzten Version

`fixed` bla
 `added` blabla
 `changed` blablabla

