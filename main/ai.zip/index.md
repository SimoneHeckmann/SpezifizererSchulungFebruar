# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://gefyra.info/training/ImplementationGuide/info.gefyra.training | *Version*:0.1.0 |
| Draft as of 2026-02-09 | *Computable Name*:SchulungsIG |

# SchulungsIG

Feel free to modify this index page with your own awesome content!

